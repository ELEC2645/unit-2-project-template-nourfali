#ifndef FUNCS_H
#define FUNCS_H

void menu_item_1(void);
void menu_item_2(void);
void menu_item_3(void);
void menu_item_4(void);
void menu_item_5(void);
void menu_item_6(void);
void menu_item_7(void);

void clear_input_buffer(void);
void back_clear_exit(void);

#endif
